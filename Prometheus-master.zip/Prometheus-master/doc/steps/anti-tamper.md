---
description: This step provides an obfuscation step, that breaks the script, when someone tries to tamper with it.
---

# Anti Tamper

### Settings

| Name        | type | description                                 | values                                  |
| ----------- | ---- | ------------------------------------------- | --------------------------------------- |
| UseDebug | boolean | Uses the debug library in lua. Disable this if you don't have access to debug library | "true","false" |
